The primary author of this project is:

- [Daan Debie](https://github.com/DandyDev) aka `DandyDev`

And Pelican Bootstrap 3 would not have been possible without the outstanding contributions of the following fine people:

- [Magnun Leno](https://github.com/magnunleno) aka `magnunleno`
- [Hilmar Lapp](https://github.com/hlapp) aka `hlapp`
- [mwcz](https://github.com/mwcz)
- [Sebastian Kempken](https://github.com/skempken) aka `skempken`
- [Sagar Behere](https://github.com/sagarbehere) aka `sagarbehere`
- [Romulo Jales](https://github.com/romulojales) aka `romulojales`
- [Mike Abrahamsen](https://github.com/mikeabrahamsen) aka `mikeabrahamsen`
- [Leonardo Giordani](https://github.com/lgiordani) aka `lgiordani`

(For a full contribution overview [look here](https://github.com/DandyDev/pelican-bootstrap3/graphs/contributors).
If you name is missing, please tell me!)