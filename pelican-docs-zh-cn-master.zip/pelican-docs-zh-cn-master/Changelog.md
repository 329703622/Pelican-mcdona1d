## pelican-docs-zh-cn @2011-12-02
* [NEW] Pelican参考文档中文版初稿发布完毕（O(∩_∩)O~算是提前送给自己一份小小的生日礼物，感谢一路走来所有的好朋友，感谢你们对我的帮助和包容，能认识你们，真好。）

## pelican-docs-zh-cn @2011-12-01
* [NEW] importer.rst 文件部分内容翻译校对完毕
* [NEW] faq.rst文件 翻译校对完毕
* [NEW] 为了不影响译文发布进程，changelog.rst、contribute.rst、report.rst 三个文件并未翻译（不影响使用，请小伙伴们谅解！！）


## pelican-docs-zh-cn @2011-11-30
* [NEW] pelican-themes.rst 文件修改校对完毕

## pelican-docs-zh-cn @2011-11-29
* [NEW] settings.rst 文件修改校对完毕（部分表格未翻译，感觉英文版更加便于理解）
* [NEW] plugins.rst 文件修改校对完毕（表格内容未翻译）
* [NEW] internals.rst 文件部分翻译完成（最后两段内容不晓得如何翻译 ∩_∩）

## pelican-docs-zh-cn @2011-11-28

* [NEW] themes.rst 文件修改校对完毕（包括格式和译文）
* [NEW] index.rst 文件修改校对完毕（包括格式和译文）
* [NEW] getting_started.rst 文件修改校对完毕（包括各式和译文）

## pelican-docs-zh-cn @2011-11-25

* [NEW] 基于.rst 文件进行修改

## pelican-docs-zh-cn @2011-11-20

* 利用业余以及周末时间完成初稿翻译
* 部分章节翻译的比较粗糙，亟需整理

## pelican-docs-zh-cn @2011-11-12


* 首次开始翻译
* 基于Pelican 3.3.0
