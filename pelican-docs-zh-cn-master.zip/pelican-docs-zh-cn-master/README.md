# pelican-docs-zh-cn

----------


<center>![logo](http://docs.getpelican.com/en/3.3.0/_static/pelican.png)
###Release：3.3.0（2013-09-24）
###感谢我的父母和妻子
###By Bravelee
</center>


##
##### Please Visit ： <http://pelican-docs-zh-cn.readthedocs.org/en/latest/>
##
## 概述

* 文档基于Sphinx + Read the Docs + Github
* 初步完成所有章节的翻译
* 正在按照计划逐章节进行部署
* 为了符合汉语语境，对原文部分内容稍作修改
* 特别感谢所有为之努力的人们！
* 由于时间仓促以及作者水平有限，该文档仅供学习参考，如有意见和建议，恳请不吝赐教，跪谢！

## To Do List

###需要进一步完成的内容：

    1. 错误修正
    
	2. 细节优化
	
	3. 待添加...
	
	4. 待添加...
    
## 关于

>Email: ms4dam0n at gmail dot com

>Twitter: [@ms4dam0n](https://twitter.com/ms4dam0n)

>Facebook: [@Bravelee](https://www.facebook.com/profile.php?id=100000081127265)


## 参考

**[1]** Pelican: <http://docs.getpelican.com/en/3.3.0/>

**[1]**  <http://pelican-zh.readthedocs.org/en/latest/zh-cn/>

